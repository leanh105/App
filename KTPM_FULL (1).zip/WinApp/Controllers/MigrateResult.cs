﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinApp.Controllers
{
    partial class HanhChinhController : DataController<Models.ViewDonVi> { }

    partial class TaiKhoanController : DataController<Models.ViewHoSo> 
    { 
    
    }
}
