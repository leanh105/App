﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace WinApp.Views.Home
{
    class Loading : BaseView<StackPanel, DataSchema>
    {
        protected override void RenderCore(ViewContext context)
        {
            base.RenderCore(context);
            
        }
    }
}
