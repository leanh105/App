<h1># ToDoList</h1>
<h3>Ứng dụng Đặt lịch nhắc nhở công việc</h3>
<h4> Mô tả ứng dụng</h4>


- Mode Light
<table>
  <tr>
    <td><img src="/Photos/splash_screen.jpg" width="300"></td>
    <td><img src="/Photos/main.jpg" width="300"></td>
  </tr>
  <tr>
    <td><img src="/Photos/Addcv.jpg" width="300"></td>
    <td><img src="/Photos/chonGio.jpg" width="300"></td>
  </tr>
  <tr>
    <td><img src="/Photos/chonNgay.jpg" width="300"></td>
    <td><img src="/Photos/updateCV.jpg" width="300"></td>
  </tr>
  <tr>
    <td><img src="/Photos/thongbao.jpg" width="300"></td>
    <td><img src="/Photos/delete.jpg" width="300"></td>
  </tr>
  <tr>
    <td><img src="/Photos/select.jpg" width="300"></td>
  </tr>
</table>

- Mode Dack
<table>
  <tr>
    <td><img src="/Photos/mode.jpg" width="300"></td>
    <td><img src="/Photos/main_dack.jpg" width="300"></td>
  </tr>
  <tr>
    <td><img src="/Photos/add_dack.jpg" width="300"></td>
    <td><img src="/Photos/update_dack.jpg" width="300"></td>
  </tr>
  <tr>
    <td> <img src="/Photos/select_dack.jpg" width="300"></td>
  </tr>

</table>
