//package com.example.todolist;
//
//import android.app.Service;
//import android.content.Intent;
//import android.media.MediaPlayer;
//import android.os.IBinder;
//import android.util.Log;
//
//import androidx.annotation.Nullable;
//
//public class Music extends Service {
//    MediaPlayer mediaPlayer;
//    @Nullable
//    @Override
//    public IBinder onBind(Intent intent) {
//        return null;
//    }
//
//    @Override
//    public int onStartCommand(Intent intent, int flags, int startId) {
//        mediaPlayer = MediaPlayer.create(this, R.raw.sakura);
//        mediaPlayer.start();
//        return START_NOT_STICKY;
//    }
//}
package com.example.todolist;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

public class Music extends Service {
    MediaPlayer mediaPlayer;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Kiểm tra nếu Intent yêu cầu phát nhạc
        if (intent != null && intent.getBooleanExtra("playMusic", false)) {
            Log.d("MusicService", "Bắt đầu phát nhạc.");
            mediaPlayer = MediaPlayer.create(this, R.raw.lofi);
            mediaPlayer.start();
        } else {
            Log.d("MusicService", "Không có yêu cầu phát nhạc.");
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        // Dừng phát nhạc và giải phóng tài nguyên
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            Log.d("MusicService", "Dừng phát nhạc và giải phóng tài nguyên.");
        }
        super.onDestroy();
    }
}
