package com.example.todolist;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class FeedbackActivity extends AppCompatActivity {

    private EditText etFeedbackContent;
    private Button btnSendFeedback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        etFeedbackContent = findViewById(R.id.etFeedbackContent);
        btnSendFeedback = findViewById(R.id.btnSendFeedback);

        // Xử lý sự kiện khi nhấn nút Gửi
        btnSendFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendFeedback();
            }
        });
        // Xử lý sự kiện nút "Quay lại"
        Button btnBackToHome = findViewById(R.id.btnBackToHome);
        btnBackToHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Đóng Activity hiện tại để quay về Activity trước đó
            }
        });

    }

    private void sendFeedback() {
        String feedbackContent = etFeedbackContent.getText().toString().trim();

        if (feedbackContent.isEmpty()) {
            Toast.makeText(this, "Vui lòng nhập nội dung phản hồi", Toast.LENGTH_SHORT).show();
            return;
        }

        // Địa chỉ email của bạn
        String recipientEmail = "your_email@example.com"; // Thay bằng email của bạn
        String subject = "Phản hồi từ người dùng";

        // Tạo intent gửi email
        Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
        emailIntent.setData(Uri.parse("mailto:" + recipientEmail));
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
        emailIntent.putExtra(Intent.EXTRA_TEXT, feedbackContent);

        try {
            startActivity(Intent.createChooser(emailIntent, "Chọn ứng dụng để gửi email"));
        } catch (Exception e) {
            Toast.makeText(this, "Không thể mở ứng dụng email", Toast.LENGTH_SHORT).show();
        }
    }
}
