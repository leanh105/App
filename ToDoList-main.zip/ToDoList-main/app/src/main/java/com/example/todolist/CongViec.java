
package com.example.todolist;

public class CongViec {
    private int IdCV;
    private String TenCV;
    private String DateCV;
    private String TimeCV;
    private int isCompleted; // 0: Chưa hoàn thành, 1: Đã hoàn thành
    private String CompletedDate; // Ngày hoàn thành
    private String icon; // Biểu tượng (icon) cho công việc

    public CongViec(int idCV, String tenCV, String dateCV, String timeCV, int isCompleted, String completedDate, String icon) {
        IdCV = idCV;
        TenCV = tenCV;
        DateCV = dateCV;
        TimeCV = timeCV;
        this.isCompleted = isCompleted;
        this.CompletedDate = completedDate;
        this.icon = icon;
    }

    // Các phương thức getter và setter
    public int getIdCV() {
        return IdCV;
    }

    public String getTenCV() {
        return TenCV;
    }

    public String getDateCV() {
        return DateCV;
    }

    public String getTimeCV() {
        return TimeCV;
    }

    public int getIsCompleted() {
        return isCompleted;
    }

    public void setIsCompleted(int isCompleted) {
        this.isCompleted = isCompleted;
    }

    public String getCompletedDate() {
        return CompletedDate;
    }

    public void setCompletedDate(String completedDate) {
        this.CompletedDate = completedDate;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }
}