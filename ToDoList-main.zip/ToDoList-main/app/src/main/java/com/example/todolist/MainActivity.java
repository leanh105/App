package com.example.todolist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.NotificationCompat;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    Database database;
    ListView lvCongViec;
    ImageView imgAdd;
    ArrayList<CongViec> arrayCongViec;
    CongViecAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imgAdd = (ImageView) findViewById(R.id.img_add);
        lvCongViec = (ListView) findViewById(R.id.listviewCongViec);
        arrayCongViec = new ArrayList<>();

        adapter = new CongViecAdapter(this, R.layout.item_cong_viec, arrayCongViec);
        lvCongViec.setAdapter(adapter);

        //khởi tạo database GhiChu
        database = new Database(this, "ghichu.sqlite", null, 2);

        //tạo bảng CongViec
        database.QueryData("CREATE TABLE IF NOT EXISTS CongViec(Id INTEGER PRIMARY KEY AUTOINCREMENT, TenCV VARCHAR(200), DateCV VARCHAR(200), TimeCV VARCHAR(200), IsCompleted INTEGER DEFAULT 0, CompletedDate VARCHAR(10), Icon VARCHAR(10));");

        //Bảng dữ liệu ngày tháng năm sinh user
        // Tạo bảng UserInfo để lưu ngày sinh
        database.QueryData("CREATE TABLE IF NOT EXISTS UserInfo (Id INTEGER PRIMARY KEY AUTOINCREMENT, DateOfBirth VARCHAR(10));");
       // Lấy dữ liệu tại bảng CongViec
        GetDataCongViec();

        database.QueryData(
                "CREATE TABLE IF NOT EXISTS DailyTasks (" +
                        "Id INTEGER PRIMARY KEY, " +
                        "GroupId INTEGER, " +
                        "TaskDescription TEXT);"
        );

        // Import dữ liệu từ file TXT
        importDataFromFile("CongViecHangNgay.txt");


        imgAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogThem();
            }
        });

        // nhan vao button goi y
        ImageView btnSuggest = findViewById(R.id.btnSuggest);
        btnSuggest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Hiển thị hộp thoại nhập ngày sinh
                showDateInputDialog();
            }
        });

        // nhan vao button mail
        ImageView btnMail = findViewById(R.id.btnMail);
        btnMail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, FeedbackActivity.class);
                startActivity(intent);
            }
        });


        // nhan vao button lich su
        ImageView btnHistory = findViewById(R.id.btnHistory);
        btnHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCompletedTasksLast7Days();
            }
        });

        ImageView btnCalender = findViewById(R.id.btnCalender);
        btnCalender.setOnClickListener(v -> showCustomCalendarDialog()
        );





    }



    // Hiển thị DatePickerDialog và đánh dấu ngày có công việc đã hoàn thành
    private void showCustomCalendarDialog() {
        // Tạo Dialog tùy chỉnh
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_calendar_tasks);

        // Tham chiếu các thành phần trong layout
        DatePicker datePicker = dialog.findViewById(R.id.datePicker);
        TextView tvNoTasks = dialog.findViewById(R.id.tvNoTasks);
        ListView lvCompletedTasks = dialog.findViewById(R.id.lvCompletedTasks);
        Button btnCloseDialog = dialog.findViewById(R.id.btnCloseDialog);

        // Lắng nghe sự kiện khi người dùng chọn ngày
        datePicker.init(
                Calendar.getInstance().get(Calendar.YEAR),
                Calendar.getInstance().get(Calendar.MONTH),
                Calendar.getInstance().get(Calendar.DAY_OF_MONTH),
                new DatePicker.OnDateChangedListener() {
                    @Override
                    public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        // Xử lý khi người dùng chọn ngày
                        String selectedDate = String.format(Locale.getDefault(), "%02d/%02d/%04d", dayOfMonth, monthOfYear + 1, year);

                        // Lấy danh sách công việc hoàn thành từ cơ sở dữ liệu
                        Cursor cursor = database.GetData(
                                "SELECT * FROM CongViec WHERE IsCompleted = 1 AND CompletedDate = '" + selectedDate + "'"
                        );

                        ArrayList<String> completedTasks = new ArrayList<>();
                        while (cursor.moveToNext()) {
                            String task = cursor.getString(1); // Tên công việc
                            String time = cursor.getString(3); // Giờ thực hiện
                            completedTasks.add(task + " - " + time);
                        }
                        cursor.close();

                        // Hiển thị danh sách hoặc thông báo không có công việc
                        if (completedTasks.isEmpty()) {
                            tvNoTasks.setVisibility(View.VISIBLE);
                            lvCompletedTasks.setVisibility(View.GONE);
                        } else {
                            tvNoTasks.setVisibility(View.GONE);
                            lvCompletedTasks.setVisibility(View.VISIBLE);

                            // Sử dụng ArrayAdapter để hiển thị danh sách công việc
                            ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, completedTasks);
                            lvCompletedTasks.setAdapter(adapter);
                        }
                    }
                }
        );

        // Xử lý sự kiện khi nhấn nút "Đóng"
        btnCloseDialog.setOnClickListener(v -> dialog.dismiss());

        // Hiển thị Dialog
        dialog.show();
    }










    private void showDateInputDialog() {
        // Lấy ngày sinh từ cơ sở dữ liệu
        String dateOfBirth = getDateOfBirth();

        if (dateOfBirth == null || dateOfBirth.isEmpty()) {
            // Nếu chưa có ngày sinh, hiển thị thông báo yêu cầu nhập
            Toast.makeText(MainActivity.this, "Chưa có ngày tháng năm sinh, vui lòng nhập!", Toast.LENGTH_SHORT).show();
        } else {
            // Nếu đã có ngày sinh, hiển thị gợi ý dựa trên cung hoàng đạo
            String zodiacSign = getZodiacSign(dateOfBirth);

            if (zodiacSign != null) {
                // Hiển thị gợi ý dựa trên cung hoàng đạo
                showSuggestion(zodiacSign);
            } else {
                Toast.makeText(MainActivity.this, "Ngày sinh không hợp lệ!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private String getDateOfBirth() {
        String dateOfBirth = null;

        // Truy vấn dữ liệu từ bảng UserInfo
        Cursor cursor = database.GetData("SELECT DateOfBirth FROM UserInfo LIMIT 1");

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                // Lấy giá trị từ cột DateOfBirth
                dateOfBirth = cursor.getString(cursor.getColumnIndex("DateOfBirth"));
            }
            cursor.close(); // Đóng Cursor sau khi sử dụng
        }

        return dateOfBirth;
    }
    private String getZodiacSign(String birthDate) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            Date date = sdf.parse(birthDate);
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);

            int day = cal.get(Calendar.DAY_OF_MONTH);
            int month = cal.get(Calendar.MONTH) + 1;

            if ((month == 1 && day >= 20) || (month == 2 && day <= 18)) return "Bảo Bình";
            if ((month == 2 && day >= 19) || (month == 3 && day <= 20)) return "Song Ngư";
            if ((month == 3 && day >= 21) || (month == 4 && day <= 19)) return "Bạch Dương";
            if ((month == 4 && day >= 20) || (month == 5 && day <= 20)) return "Kim Ngưu";
            if ((month == 5 && day >= 21) || (month == 6 && day <= 20)) return "Song Tử";
            if ((month == 6 && day >= 21) || (month == 7 && day <= 22)) return "Cự Giải";
            if ((month == 7 && day >= 23) || (month == 8 && day <= 22)) return "Sư Tử";
            if ((month == 8 && day >= 23) || (month == 9 && day <= 22)) return "Xử Nữ";
            if ((month == 9 && day >= 23) || (month == 10 && day <= 22)) return "Thiên Bình";
            if ((month == 10 && day >= 23) || (month == 11 && day <= 21)) return "Bọ Cạp";
            if ((month == 11 && day >= 22) || (month == 12 && day <= 21)) return "Nhân Mã";
            if ((month == 12 && day >= 22) || (month == 1 && day <= 19)) return "Ma Kết";

            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private int getGroupIdByZodiac(String zodiacSign) {
        switch (zodiacSign) {
            case "Bảo Bình": return 1;
            case "Song Ngư": return 2;
            case "Bạch Dương": return 3;
            case "Kim Ngưu": return 4;
            case "Song Tử": return 5;
            case "Cự Giải": return 6;
            case "Sư Tử": return 7;
            case "Xử Nữ": return 8;
            case "Thiên Bình": return 9;
            case "Bọ Cạp": return 10;
            case "Nhân Mã": return 11;
            case "Ma Kết": return 12;
            default: return -1; // Giá trị không hợp lệ
        }
    }

    private void showSuggestion(String zodiacSign) {
        String suggestion = "Không có gợi ý nào!";

        try {
            // Lấy GroupId dựa trên cung hoàng đạo
            int groupId = getGroupIdByZodiac(zodiacSign);

            // Truy vấn lấy ngẫu nhiên một gợi ý từ bảng DailyTasks
            Cursor cursor = database.GetData(
                    "SELECT TaskDescription FROM DailyTasks WHERE GroupId = " + groupId + " ORDER BY RANDOM() LIMIT 1"
            );

            if (cursor.moveToFirst()) {
                suggestion = cursor.getString(0); // Lấy cột TaskDescription
            }
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
            suggestion = "Lỗi khi lấy gợi ý!";
        }

        // Hiển thị gợi ý
        Toast.makeText(this, "Gợi ý: " + suggestion, Toast.LENGTH_LONG).show();
    }

    private void showCompletedTasksLast7Days() {
        // Lấy ngày hiện tại tại thời điểm click
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        String currentDate = dateFormat.format(calendar.getTime());

        // Tính ngày 7 ngày trước đó
        calendar.add(Calendar.DAY_OF_YEAR, -7);
        String sevenDaysAgoDate = dateFormat.format(calendar.getTime());

        // Truy vấn cơ sở dữ liệu để lấy các công việc đã hoàn thành trong 7 ngày gần nhất và trước thời điểm hiện tại
        Cursor dataCongViec = database.GetData(
                "SELECT * FROM CongViec WHERE IsCompleted = 1 AND CompletedDate <= '" + currentDate + "' AND CompletedDate >= '" + sevenDaysAgoDate + "' ORDER BY CompletedDate DESC, TimeCV DESC"
        );

        ArrayList<CongViec> completedTasks = new ArrayList<>();
        while (dataCongViec.moveToNext()) {
            int id = dataCongViec.getInt(0);
            String ten = dataCongViec.getString(1);
            String ngay = dataCongViec.getString(2);
            String gio = dataCongViec.getString(3);
            int isCompleted = dataCongViec.getInt(4);
            String completedDate = dataCongViec.getString(5); // Lấy giá trị của cột CompletedDate
            String icon = dataCongViec.getString(6); // Lấy giá trị của cột Icon
            completedTasks.add(new CongViec(id, ten, ngay, gio, isCompleted, completedDate, icon));
        }

        // Hiển thị danh sách công việc đã hoàn thành
        if (completedTasks.isEmpty()) {
            Toast.makeText(this, "Không có công việc nào đã hoàn thành trong 7 ngày gần nhất.", Toast.LENGTH_SHORT).show();
        } else {
            showCompletedTasksDialog(completedTasks);
        }
    }

    private void showCompletedTasksDialog(ArrayList<CongViec> completedTasks) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Công việc đã hoàn thành trong 7 ngày gần nhất");

        // Tạo adapter để hiển thị danh sách công việc
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        for (CongViec task : completedTasks) {
            adapter.add(task.getTenCV() + " - " + task.getCompletedDate() + " " + task.getTimeCV() + " " + task.getIcon()); // Thêm icon vào danh sách
        }

        // Thiết lập adapter cho dialog
        builder.setAdapter(adapter, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Xử lý khi người dùng chọn một công việc
                CongViec selectedTask = completedTasks.get(which);
                Toast.makeText(MainActivity.this, "Đã chọn: " + selectedTask.getTenCV(), Toast.LENGTH_SHORT).show();
            }
        });

        // Thêm nút "Xóa lịch sử"
        builder.setPositiveButton("Đóng", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.setNegativeButton("Xóa lịch sử", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Xóa toàn bộ lịch sử công việc đã hoàn thành trong 7 ngày gần nhất
                deleteCompletedTasksLast7Days();

                // Đóng dialog sau khi xóa
                dialog.dismiss();

                // Hiển thị lại danh sách công việc đã hoàn thành (nếu cần)
                showCompletedTasksLast7Days();
            }
        });

        builder.show();
    }

    public void updateTaskCompletionStatus(int taskId, int isCompleted) {
        String currentDate = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        if (isCompleted == 1) {
            // Nếu công việc được đánh dấu là hoàn thành, cập nhật CompletedDate thành thời gian hiện tại
            database.QueryData("UPDATE CongViec SET IsCompleted = " + isCompleted + ", CompletedDate = '" + currentDate + "' WHERE Id = " + taskId);
        } else {
            // Nếu công việc không được đánh dấu là hoàn thành, đặt CompletedDate thành NULL
            database.QueryData("UPDATE CongViec SET IsCompleted = " + isCompleted + ", CompletedDate = NULL WHERE Id = " + taskId);
        }
    }

    private void deleteCompletedTasksLast7Days() {
        // Lấy ngày hiện tại tại thời điểm click
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        String currentDate = dateFormat.format(calendar.getTime());

        // Tính ngày 7 ngày trước đó
        calendar.add(Calendar.DAY_OF_YEAR, -7);
        String sevenDaysAgoDate = dateFormat.format(calendar.getTime());

        // Xóa các công việc đã hoàn thành trong 7 ngày gần nhất
        database.QueryData(
                "DELETE FROM CongViec WHERE IsCompleted = 1 AND CompletedDate <= '" + currentDate + "' AND CompletedDate >= '" + sevenDaysAgoDate + "'"
        );

        // Thông báo xóa thành công
        Toast.makeText(this, "Đã xóa lịch sử công việc trong 7 ngày gần nhất.", Toast.LENGTH_SHORT).show();

    }

    //dialog sửa ghi chú
    public void DialogSuaCongViec(String ten, String date, String time, final int id, String icon) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_sua);

        final EditText edtTenCV = (EditText) dialog.findViewById(R.id.editTextTenCVEdit);
        final TextView tvDate = (TextView) dialog.findViewById(R.id.textDateCVEdit);
        final TextView tvTime = (TextView) dialog.findViewById(R.id.textTimeCVEdit);
        final Spinner spinnerIcon = (Spinner) dialog.findViewById(R.id.spinnerIconEdit);

        // Danh sách các icon
        String[] icons = {"⚽️", "🏀", "🏈", "🎾", "⛳️", "🎤", "🎧", "🎮", "🍿", "🎂"};
        ArrayAdapter<String> iconAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, icons);
        iconAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerIcon.setAdapter(iconAdapter);

        // Đặt giá trị hiện tại cho Spinner
        int iconPosition = iconAdapter.getPosition(icon);
        spinnerIcon.setSelection(iconPosition);

        Button btnXacNhan = (Button) dialog.findViewById(R.id.buttonXacNhan);
        Button btnHuy = (Button) dialog.findViewById(R.id.buttonHuyEdit);

        edtTenCV.setText(ten);
        tvDate.setText(date);
        tvTime.setText(time);

        tvTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChonGio(tvTime, edtTenCV);
            }
        });

        tvDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChonNgay(tvDate);
            }
        });

        btnHuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        btnXacNhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tenMoi = edtTenCV.getText().toString().trim();
                String dateMoi = tvDate.getText().toString().trim();
                String timeMoi = tvTime.getText().toString().trim();
                String iconMoi = spinnerIcon.getSelectedItem().toString(); // Lấy icon được chọn

                database.QueryData("UPDATE CongViec SET TenCV ='" + tenMoi + "', DateCV = '" + dateMoi + "', TimeCV = '" + timeMoi + "', Icon = '" + iconMoi + "' WHERE Id = '" + id + "'");
                Toast.makeText(MainActivity.this, "Đã cập nhập", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
                GetDataCongViec();
            }
        });

        dialog.show();
    }

    //dialog xác nhận xóa ghi chú
    public void DialogXoaCV(String tencv, final int id){
        AlertDialog.Builder dialogXoa = new AlertDialog.Builder(this);
        dialogXoa.setMessage("Bạn có muốn xóa không?");
        dialogXoa.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                database.QueryData("DELETE FROM CongViec WHERE Id = '"+id+"'");
                Toast.makeText(MainActivity.this, "Đã xóa",Toast.LENGTH_SHORT).show();
                GetDataCongViec();
            }
        });
        dialogXoa.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        dialogXoa.show();
    }

    //lấy dữ liệu trong bảng CongViec
    private void GetDataCongViec() {
        Cursor dataCongViec = database.GetData(
                "SELECT * FROM CongViec WHERE IsCompleted = 0 ORDER BY DateCV ASC, TimeCV ASC"
        );

        arrayCongViec.clear();
        while (dataCongViec.moveToNext()) {
            int id = dataCongViec.getInt(0);
            String ten = dataCongViec.getString(1);
            String ngay = dataCongViec.getString(2);
            String gio = dataCongViec.getString(3);
            int isCompleted = dataCongViec.getInt(4);
            String completedDate = dataCongViec.getString(5); // Lấy giá trị của cột CompletedDate
            String icon = dataCongViec.getString(6); // Lấy giá trị của cột Icon
            arrayCongViec.add(new CongViec(id, ten, ngay, gio, isCompleted, completedDate, icon)); // Thêm icon vào đối tượng CongViec
        }
        adapter.notifyDataSetChanged();
    }

    //chọn sự kiện Thêm ghi chú trên thanh menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_setting, menu);

        // Sử dụng Reflection để kích hoạt icon trong menu
        try {
            Method method = menu.getClass().getDeclaredMethod("setOptionalIconsVisible", boolean.class);
            method.setAccessible(true);
            method.invoke(menu, true);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.tt_darkMode:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                finish();
                break;
            case R.id.tt_lightMode:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                finish();
                break;
            case R.id.tt_dateBirth:
                showDateOfBirthDialog();
                break;
            default:
                break;
        }
        return true;
    }

    private void showDateOfBirthDialog() {
        final Calendar calendar = Calendar.getInstance();
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int month = calendar.get(Calendar.MONTH);
        int year = calendar.get(Calendar.YEAR);

        // Hiển thị DatePickerDialog để chọn ngày tháng năm sinh
        DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this, (view, selectedYear, selectedMonth, selectedDayOfMonth) -> {
            // Sau khi chọn ngày, lưu vào cơ sở dữ liệu
            String selectedDate = String.format(Locale.getDefault(), "%02d/%02d/%04d", selectedDayOfMonth, selectedMonth + 1, selectedYear);
            if (isValidDate(selectedDate)) {
                saveDateOfBirth(selectedDate);
                Toast.makeText(MainActivity.this, "Đã lưu ngày sinh: " + selectedDate, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Ngày sinh không hợp lệ!", Toast.LENGTH_SHORT).show();
            }
        }, year, month, day);

        // Hiển thị DatePickerDialog
        datePickerDialog.show();
    }


    private boolean isValidDate(String date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        sdf.setLenient(false);

        try {
            sdf.parse(date);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    private void saveDateOfBirth(String dateOfBirth) {
        // Xóa dữ liệu cũ trong bảng UserInfo (nếu có)
        database.QueryData("DELETE FROM UserInfo");

        // Thêm ngày sinh mới vào bảng UserInfo
        database.QueryData("INSERT INTO UserInfo (Id, DateOfBirth) VALUES (null, '" + dateOfBirth + "');");
    }


    // thêm ghi chú
    private void DialogThem() {
        final Dialog dialog = new Dialog(this);

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_them_cong_viec);

        final EditText edtTen = (EditText) dialog.findViewById(R.id.editTextTenCV);
        final TextView txtDate = (TextView) dialog.findViewById(R.id.textDateCV);
        final TextView txtTime = (TextView) dialog.findViewById(R.id.textTimeCV);
        final Spinner spinnerIcon = (Spinner) dialog.findViewById(R.id.spinnerIcon); // Thêm Spinner để chọn icon

        // Danh sách các icon
        String[] icons = {"  ", "⚽️", "🏀", "🏈", "🎾", "⛳️", "🎤", "🎧", "🎮", "🍿", "🎂", "🥞", "🍕", "👩‍🍳", "🍻", "🥂", "🍽", "🚲", "🛩", "🛶", "⛱", "💻", "💣", "💊", "❤️"};
        ArrayAdapter<String> iconAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, icons);
        iconAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerIcon.setAdapter(iconAdapter);

        Button btnThem = (Button) dialog.findViewById(R.id.buttonThem);
        Button btnHuy = (Button) dialog.findViewById(R.id.buttonHuy);

        //bắt sự kiện chọn giờ
        txtTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChonGio(txtTime, edtTen);
            }
        });
        //bắt sự kiện chọn ngày
        txtDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChonNgay(txtDate);
            }
        });
        //bắt sự kiện xác nhận thêm ghi chú
        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tencv = edtTen.getText().toString();
                String datecv = txtDate.getText().toString();
                String timecv = txtTime.getText().toString();
                String icon = spinnerIcon.getSelectedItem().toString(); // Lấy icon được chọn

                if (tencv.equals("")) {
                    Toast.makeText(MainActivity.this, "Vui lòng nhập ghi chú công việc.", Toast.LENGTH_SHORT).show();
                } else if (icon.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Vui lòng chọn biểu tượng.", Toast.LENGTH_SHORT).show();
                } else {
                    // Insert vào database với icon
                    database.QueryData("INSERT INTO CongViec (Id, TenCV, DateCV, TimeCV, IsCompleted, CompletedDate, Icon) VALUES (null, '" + tencv + "','" + datecv + "','" + timecv + "', 0, NULL, '" + icon + "');");
                    Toast.makeText(MainActivity.this, "Đã thêm.", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                    GetDataCongViec();
                }
            }
        });
        //bắt sự kiện hủy
        btnHuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    //dialog chọn giờ
    private void ChonGio(final TextView txtTime, final EditText edtTen) {
        final Calendar calendar = Calendar.getInstance();
        int gio = calendar.get(Calendar.HOUR_OF_DAY);
        int phut = calendar.get(Calendar.MINUTE);

        final TimePickerDialog timePickerDialog = new TimePickerDialog(this, (view, hourOfDay, minute) -> {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
            calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
            calendar.set(Calendar.MINUTE, minute);

            txtTime.setText(simpleDateFormat.format(calendar.getTime()));

            // Kiểm tra tên công việc trước khi thiết lập báo thức
            if (edtTen.getText().toString().trim().isEmpty()) {
                Toast.makeText(MainActivity.this, "Vui lòng nhập tên công việc trước khi đặt báo thức.", Toast.LENGTH_SHORT).show();
            } else {
                setMultipleAlarms(calendar, edtTen);
            }
        }, gio, phut, true);

        timePickerDialog.show();
    }


    //dialog chọn ngày
    private void ChonNgay(final TextView txtDate) {
        final Calendar calendar = Calendar.getInstance();
        int ngay = calendar.get(Calendar.DATE);
        int thang = calendar.get(Calendar.MONTH);
        int nam = calendar.get(Calendar.YEAR);
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                calendar.set(year,month,dayOfMonth);
                txtDate.setText(simpleDateFormat.format(calendar.getTime()));
            }
        }, nam, thang, ngay);
        datePickerDialog.show();
    }

    //đặt báo thức
    public void setMultipleAlarms(Calendar calendar, EditText edtTen) {
        // Kiểm tra nếu thời gian được chọn đã qua
        if (calendar.getTimeInMillis() <= System.currentTimeMillis()) {
            Toast.makeText(MainActivity.this, "Thời gian đặt lịch phải ở tương lai!", Toast.LENGTH_SHORT).show();
            return; // Không tiếp tục nếu thời gian không hợp lệ
        }
        AlarmManager manager = (AlarmManager) getSystemService(ALARM_SERVICE);
        Intent intent = new Intent(MainActivity.this, AlarmReceiver.class);
        intent.setAction("com.example.todolist.ALARM_TRIGGERED");
        intent.putExtra("taskName", edtTen.getText().toString());
        int requestCode = (int) calendar.getTimeInMillis();
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                MainActivity.this, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT
        );

        // Đặt báo thức đúng giờ
        manager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);

        // Đặt thông báo trước 5 phút
        Calendar notificationTime = (Calendar) calendar.clone();
        notificationTime.add(Calendar.MINUTE, -5);
        Intent notificationIntent = new Intent(MainActivity.this, AlarmReceiver.class);
        notificationIntent.setAction("com.example.todolist.NOTIFICATION_TRIGGERED");
        notificationIntent.putExtra("taskName", edtTen.getText().toString());
        notificationIntent.putExtra("notificationId", requestCode);

        PendingIntent notificationPendingIntent = PendingIntent.getBroadcast(
                MainActivity.this, requestCode + 1, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT
        );

        manager.set(AlarmManager.RTC_WAKEUP, notificationTime.getTimeInMillis(), notificationPendingIntent);
    }



    private void addNotification(String des, int notificationId) {
        String strTitle = "To Do List";
        String strMsg = des;

        Intent notificationIntent = new Intent(this, NotificationDetailActivity.class);
        notificationIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        notificationIntent.putExtra("message", strMsg);
        notificationIntent.putExtra("title", strTitle);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "TDL_1")
                .setSmallIcon(R.drawable.icon1)
                .setContentTitle(strTitle)
                .setContentText(strMsg)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
                .setColor(Color.BLUE)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .addAction(R.mipmap.ic_launcher, "DỪNG", pendingIntent);

        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(notificationId, builder.build());
    }



    private void importDataFromFile(String filePath) {
        try {
            InputStream inputStream = getAssets().open(filePath); // Nếu file nằm trong thư mục assets
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\t");
                if (parts.length == 3) {
                    int id = Integer.parseInt(parts[0].trim());
                    int groupId = Integer.parseInt(parts[1].trim());
                    String task = parts[2].trim();

                    // Chèn dữ liệu vào bảng
                    database.QueryData(
                            "INSERT INTO DailyTasks (Id, GroupId, TaskDescription) VALUES (" +
                                    id + ", " + groupId + ", '" + task + "');"
                    );
                } else {
                    Log.e("IMPORT", "Dòng không hợp lệ: " + line);
                }
            }

            reader.close();
        } catch (Exception e) {
            Log.e("IMPORT", "Lỗi khi nhập dữ liệu từ file: " + e.getMessage());
        }
    }


}
