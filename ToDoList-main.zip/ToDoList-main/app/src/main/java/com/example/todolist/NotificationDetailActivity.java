package com.example.todolist;

import androidx.appcompat.app.AppCompatActivity;
import android.app.NotificationManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class NotificationDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_notification_detail);
        Button btn_stop = (Button) findViewById(R.id.btn_stop);
        btn_stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Dừng phát nhạc
                Intent stopMusicIntent = new Intent(NotificationDetailActivity.this, Music.class);
                stopService(stopMusicIntent);

                // Hủy thông báo
                NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                if (notificationManager != null) {
                    // Hủy tất cả thông báo hoặc chỉ thông báo có ID cụ thể
                    notificationManager.cancelAll(); // Hủy tất cả thông báo
                }

                // Đóng Activity
                finish();
            }
        });


    }

}
