
package com.example.todolist;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.core.app.NotificationCompat;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction() != null) {
            String taskName = intent.getStringExtra("taskName");

            if (intent.getAction().equals("com.example.todolist.ALARM_TRIGGERED")) {
                Log.d("AlarmReceiver", "Báo thức được kích hoạt: " + taskName);

                // Khởi chạy dịch vụ phát nhạc
                Intent musicIntent = new Intent(context, Music.class);
                musicIntent.putExtra("playMusic", true);
                context.startService(musicIntent);

                // Tạo thông báo báo thức
                createNotification(context, taskName, "Báo thức!");

            } else if (intent.getAction().equals("com.example.todolist.NOTIFICATION_TRIGGERED")) {
                Log.d("AlarmReceiver", "Hiển thị thông báo trước 5 phút: " + taskName);

                // Tạo thông báo trước 5 phút
                createNotification(context, taskName, "Sắp đến giờ!");
            }
        }
    }

    private void createNotification(Context context, String taskName, String title) {
        Intent notificationIntent = new Intent(context, NotificationDetailActivity.class);
        notificationIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "TDL_1")
                .setSmallIcon(R.drawable.icon1)
                .setContentTitle(title)
                .setContentText("Công việc: " + taskName)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.notify((int) System.currentTimeMillis(), builder.build()); // ID duy nhất cho thông báo
        }
    }
}
